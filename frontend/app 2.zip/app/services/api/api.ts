import { supabase } from '../supabaseClient';

export class Api {

	async getData(table: string) {
		const { data, error } = await supabase.from(table).select('*');
		if (error) throw new Error(error.message);
		return data;
	}

	async insertData(table: string, payload: any) {
		const { data, error } = await supabase.from(table).insert([payload]);
		if (error) throw new Error(error.message);
		return data;
	}

	async updateData(table: string, id: number, payload: any) {
		const { data, error } = await supabase.from(table).update(payload).eq('id', id);
		if (error) throw new Error(error.message);
		return data;
	}

	async deleteData(table: string, id: number) {
		const { data, error } = await supabase.from(table).delete().eq('id', id);
		if (error) throw new Error(error.message);
		return data;
	}
}