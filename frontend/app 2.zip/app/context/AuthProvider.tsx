import React, { createContext, useContext, useState, useEffect } from 'react';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../services/supabaseClient';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
	const [user, setUser] = useState(null);
	const [authNumber, setAuthNumber] = useState("");
	const [authToken, setAuthToken] = useState(null);
	const [loading, setLoading] = useState(true);

	const isAuthenticated = !!authToken;

	useEffect(() => {
		const loadSession = async () => {
			try {
				const sessionString = await AsyncStorage.getItem('supabaseSession');
				if (sessionString) {
					const session = JSON.parse(sessionString);
					await supabase.auth.setSession(session);
					setUser(session.user);
					setAuthToken(session.access_token);
				}
			} catch (error) {
				console.error("Failed to load session:", error);
			} finally {
				setLoading(false);
			}
		};

		loadSession();

		const { subscription } = supabase.auth.onAuthStateChange((_event, session) => {
			if (session) {
				setUser(session.user);
				setAuthToken(session.access_token);
				AsyncStorage.setItem('supabaseSession', JSON.stringify(session));
			} else {
				setUser(null);
				clearAuthToken();
			}
		});

		return () => {
			if (subscription) subscription.unsubscribe();
		};
	}, []);

	const setAuthNumberFunc = (value) => {
		setAuthNumber(value.replace(/ /g, ""));
	};

	const signInWithPhoneNumber = async (phoneNumber) => {
		try {
			const { data, error } = await supabase.auth.signInWithOtp({
				phone: phoneNumber,
				options: {
					ttl: 300, // تعيين الصلاحية إلى 5 دقائق (300 ثانية)
				}
			});
			if (error) throw error;

		} catch (error) {
			console.error("Failed to sign in with phone number:", error);
			throw error;
		}
	};

	const verifyOtp = async (phoneNumber, otp, navigation) => {
		try {
			const { data, error } = await supabase.auth.verifyOtp({
				phone: phoneNumber,
				token: otp,
				type: 'sms',
			});

			if (error) {
				Alert.alert('خطأ', 'الرمز غير صالح أو انتهت صلاحيته. يرجى المحاولة مرة أخرى.');
			}

			if (data?.session) {
				setUser(data.session.user);
				setAuthToken(data.session.access_token);
				await AsyncStorage.setItem('supabaseSession', JSON.stringify(data.session));
				navigation.navigate('Home');
			}
		} catch (error) {
			Alert.alert('خطأ', 'حدث خطأ أثناء التحقق من الرمز.');
		}
	};

	const signOut = async () => {
		try {
			const { error } = await supabase.auth.signOut();
			if (error) throw error;
			setUser(null);
			clearAuthToken();
		} catch (error) {
			console.error("Failed to sign out:", error);
			throw error;
		}
	};

	const clearAuthToken = async () => {
		try {
			await AsyncStorage.removeItem('supabaseSession');
			setAuthToken(null);
		} catch (error) {
			console.error("Failed to clear token:", error);
		}
	};

	return (
		<AuthContext.Provider value={{
			user,
			authNumber,
			authToken,
			loading,
			isAuthenticated,
			setAuthNumber: setAuthNumberFunc,
			signInWithPhoneNumber,
			verifyOtp,
			signOut,
		}}>
			{children}
		</AuthContext.Provider>
	);
};

export const useAuth = () => {
	return useContext(AuthContext);
};