import jwt, { JwtPayload } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import dotenv from 'dotenv';

dotenv.config();

const jwtSecret: string = process.env.JWT_SECRET as string;

if (!jwtSecret) {
	console.error("[JWT] : Secret is not defined. Set JWT_SECRET in environment variables.");
	process.exit(1);
}

interface AuthenticatedRequest extends Request {
	user?: string | JwtPayload;
}

function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
	const token = req.header("x-auth-token");
	if (!token) {
		return res.status(401).json({ error: "Authorization denied: No token provided" });
	}

	try {
		const decoded = jwt.verify(token, jwtSecret);
		req.user = decoded;
		next();
	} catch (err) {
		res.status(401).json({ error: "Invalid token: Token verification failed" });
	}
}

export default authenticateToken;